<tr>
		<td>Asal Sekolah
			: <input type="text" name="asal_sekolah" id="asal_sekolah"> 
			Kelas : <select name="kelas" id="kelas">
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				</select>
		</td>
		<td>Asal Sekolah
			: <input type="text" name="asal_sekolah2" id="asal_sekolah2"> 
			Kelas : <select name="kelas2" id="kelas2">
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				</select>
		</td>
</tr>
<tr>
	<td>Scan Akta Kelahiran : <input type="file" id="akta" name="akta"></br>Max size: 3 MB</td>
	<td>Scan Akta Kelahiran : <input type="file" id="akta2" name="akta2"></br>Max size: 3 MB</td>
</tr>
<tr>
	<td>Scan Ijazah : <input type="file" id="ijazah" name="ijazah"></br>Max size: 3 MB</td>
	<td>Scan Ijazah : <input type="file" id="ijazah2" name="ijazah2"></br>Max size: 3 MB</td>
</tr>