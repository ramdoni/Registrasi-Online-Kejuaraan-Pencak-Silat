<tr>
		<td>Asal Sekolah</td>
		<td>: <input type="text" name="asal_sekolah" id="asal_sekolah"> 
		Kelas : <select name="kelas" id="kelas">
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
				<option value="11">11</option>
				<option value="12">12</option>
				</select>
		</td>
</tr>
<tr>
	<td>Scan Akta Kelahiran</td>
	<td>: <input type="file" id="akta" name="akta"> Max size: 3 MB</td>
</tr>
<tr>
	<td>Scan Ijazah</td>
	<td>: <input type="file" id="ijazah" name="ijazah"> Max size: 3 MB</td>
</tr>