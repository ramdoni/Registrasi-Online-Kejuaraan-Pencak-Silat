<?php 
	include "../backend/config/conn.php";
?>
<html>
<head>
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  <script src="js/jquery.min.js"></script>
  <script src="js/bootstrap.min.js"></script>
</head>
<body>
<div class="container">
<h1>MONITORING NILAI TGR</h1>
<div id="jadwaltanding" class="table-responsive">
<table class="table table-bordered table-striped">
	<tr class="text-center">
		<td><a href="view_tunggal.php" class="btn btn-warning" role="button">TUNGGAL</a></td>
		<td><a href="view_ganda.php" class="btn btn-warning" role="button">GANDA</a></td>
		<td><a href="view_regu.php" class="btn btn-warning" role="button">REGU</a></td>
	</tr>
</table>
</div>
</div>
</body>
</html>