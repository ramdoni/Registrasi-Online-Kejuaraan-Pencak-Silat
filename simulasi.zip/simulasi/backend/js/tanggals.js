$(document).ready(
         function() {
   		  $(function() {
               $("#tgls").datepicker({
				  dateFormat:'yy-mm-dd',
                  showButtonPanel: true,
                  //minDate: new Date(),
                  showTime: true
               });
            });
   	   });