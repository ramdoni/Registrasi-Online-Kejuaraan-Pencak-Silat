<?php

  /*
  *---------------------------------------------------------------
  * E-REGISTRASI PENCAK SILAT Versi 3.0
  *---------------------------------------------------------------
  * This program is free software; you can redistribute it and/or
  * modify it under the terms of the GNU General Public License
  * as published by the Free Software Foundation; either version 2
  * of the License, or (at your option) any later version.
  *
  * This program is distributed in the hope that it will be useful,
  * but WITHOUT ANY WARRANTY; without even the implied warranty of
  * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
  * GNU General Public License for more details.
  *
  * You should have received a copy of the GNU General Public License
  * along with this program; if not, write to the Free Software
  * Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA 02110-1301, USA.
  *
  * @Author Yudha Yogasara
  * yudha.yogasara@gmail.com
  * @Contributor Sofyan Hadi, Satria Salam
  *
  * IPSI KABUPATEN TANGERANG
  * SALAM OLAHRAGA
  */ 
	
	include "backend/config/conn.php";

?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Registrasi Pencak Silat</title>
<!-- CSS Files -->
    <link href="css/reset.css" rel="stylesheet" type="text/css" media="all" />
    <link href="css/stylesheet.css" rel="stylesheet" type="text/css" media="all" />
	
</head>
<body>
<!-- Start Wrapper -->
<div id="wrapper">
  <?php 
	include "headmenu.php";
  ?>

  <!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div align="center">
<table width="100%" border="0">
  <tr>
    <td bgcolor="#99CCFF"><center>KELAS</center></td>
    <td colspan="4" bgcolor="#99CCFF"><center>GOLONGAN</center></td>
  </tr>
  <tr>
    <td bgcolor="#99CCFF"><center>PERTANDINGAN</center></td>
    <td bgcolor="#99CCFF"><center>USIA DINI</center></td>
    <td bgcolor="#99CCFF"><center>PRA REMAJA</center></td>
    <td bgcolor="#99CCFF"><center>REMAJA</center></td>
    <td bgcolor="#99CCFF"><center>DEWASA</center></td>
  </tr>
  <tr>
    <td>Kelas A</td>
    <td>26 - 28 Kg</td>
    <td>33 - 36 Kg</td>
    <td>39 - 43 Kg</td>
    <td>45 - 50 Kg</td>
  </tr>
  <tr bgcolor="#eeeeee">
    <td>Kelas B</td>
    <td>28 - 30 Kg</td>
    <td>36 - 39 Kg</td>
    <td>43 - 47 Kg</td>
    <td>50 - 55 Kg</td>
  </tr>
  <tr>
    <td>Kelas C</td>
    <td>30 - 32 Kg</td>
    <td>39 - 42 Kg</td>
    <td>47 - 51 Kg</td>
    <td>55 - 60 Kg</td>
  </tr>
  <tr bgcolor="#eeeeee">
    <td>Kelas D</td>
    <td>32 - 34 Kg</td>
    <td>42 - 45 Kg</td>
    <td>51 - 55 Kg</td>
    <td>60 - 65 Kg</td>
  </tr>
  <tr>
    <td>Kelas E</td>
    <td>34 - 36 Kg</td>
    <td>45 - 48 Kg</td>
    <td>55 - 59 Kg</td>
    <td>65 - 70 Kg</td>
  </tr>
  <tr bgcolor="#eeeeee">
    <td>Kelas F</td>
    <td>36 - 38 Kg</td>
    <td>48 - 51 Kg</td>
    <td>59 - 63 Kg</td>
    <td>70 - 75 Kg</td>
  </tr>
  <tr>
    <td>Kelas G</td>
    <td>38 - 40 Kg</td>
    <td>51 - 54 Kg</td>
    <td>63 - 67 Kg</td>
    <td>75 - 80 Kg</td>
  </tr>
  <tr bgcolor="#eeeeee">
    <td>Kelas H</td>
    <td>40 - 42 Kg</td>
    <td>54 - 57 Kg</td>
    <td>67 - 71 Kg</td>
    <td>80 - 85 Kg</td>
  </tr>
  <tr>
    <td>Kelas I</td>
    <td>42 - 44 Kg</td>
    <td>57 - 60 Kg</td>
    <td>71 - 75 Kg</td>
    <td>85 - 90 Kg</td>
  </tr>
  <tr bgcolor="#eeeeee">
    <td>Kelas J</td>
    <td>44 - 46 Kg</td>
    <td>60 - 63 Kg</td>
    <td>75 - 79 Kg</td>
    <td>90 - 95 Kg</td>
  </tr>
</table>
</div>

</body>
</html>


<!-- start: footer -->
<div id="footer">
	<p>Copyleft 2016 <?php echo " - ".date("Y"); ?> <a href="developer.php">IPSI Kabupaten Tangerang</a></p>
	<!-- end: footer -->
</div>
<!-- end: footer -->
</div>
  </body>
</html>