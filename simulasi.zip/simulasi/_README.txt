*---------------------------------------------------------------
* E-REGISTRASI PENCAK SILAT Versi 18.07
* https://eregistrasi-kejuaraan-silat.sourceforge.io/
*---------------------------------------------------------------

DAFTAR PERBAIKAN VERSI 18.07

Mulai saat ini dan selanjutnya Aplikasi Registrasi Online Kejuaraan Pencak Silat akan menggunakan versi yang menunjukkan Tahun dan Bulan saat aplikasi dirilis.

Daftar Perbaikan Aplikasi Registrasi Online Kejuaraan Pencak Silat Versi 18.07 :

+ Penambahan suara pada klik tombol penilaian wasit juri
+ Perubahan desain modul monitoring nilai
+ Penambahan modul statistik pertandingan
+ Penambahan modul penilaian digital untuk kelas TGR

+ Aplikasi wasit juri TGR terdapat di dalam folder "juritgr"
+ Monitoring Penilaian TGR terdapat di dalam folder "nilaitgr"
+ Perbaikan beberapa bugs yang berhasil ditemukan


* @Author Yudha Yogasara - yudha.yogasara@gmail.com
* @Contributor Sofyan Hadi, Satria Salam
*
* IPSI KABUPATEN TANGERANG
* 
* ...::: Made with love and caffeine :::...
*
* Tangerang, Juli 2018

***************************************************

Aplikasi Registrasi Online Kejuaraan Pencak Silat bersifat open source dan gratis. Anda dapat dengan bebas menggunakannya tanpa biaya sepeserpun. Bagi Anda yang ingin berkontribusi secara finansial berapapun nilainya dapat melakukan transfer ke nomor rekening berikut ini:

Bank Syariah Mandiri
No. Rekening 70 888 05 148 
Atas Nama Yudha Yogasara